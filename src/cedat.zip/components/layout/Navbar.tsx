import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Menu, X, User, Settings, LogOut, Shield } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Navbar() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();

  const scrollToTop = () => window.scrollTo(0, 0);

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/events", label: "Events" },
    { href: "/gallery", label: "Gallery" },
    { href: "/startup-world-cup", label: "Startup World Cup" },
    { href: "/askus", label: "Ask Us" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border/40">
      <div className="container mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-stretch justify-between">
        {/* Logo - fills navbar height */}
        <Link href="/" onClick={scrollToTop} className="flex-shrink-0 flex items-center h-16 sm:h-20">
          <img src="/cedat-logo.png" alt="CEDAT" className="h-full w-auto object-contain" />
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href} onClick={scrollToTop}>
              <span
                className={cn(
                  "text-sm font-medium transition-colors hover:text-accent cursor-pointer",
                  location === link.href
                    ? "text-foreground"
                    : "text-muted-foreground"
                )}
              >
                {link.label}
              </span>
            </Link>
          ))}
        </div>

        {/* Auth Buttons */}
        <div className="hidden md:flex items-center gap-4">
          {isAuthenticated ? (
            <div className="flex items-center gap-4">
              {/* Admin Link */}
              {user?.is_admin && (
                <Link href="/admin">
                  <Button variant="outline" size="sm" className="rounded-full">
                    <Shield className="w-4 h-4 mr-2" />
                    Admin
                  </Button>
                </Link>
              )}

              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="rounded-full focus:ring-0 focus-visible:ring-0">
                    <User className="w-4 h-4 mr-2" />
                    {user?.full_name.split(' ')[0]}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56 bg-white border border-gray-200 shadow-lg">
                  <DropdownMenuLabel className="text-gray-900 font-semibold">My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator className="bg-gray-200" />
                  {user?.profile_slug && (
                    <Link href={`/member/${user.profile_slug}`}>
                      <DropdownMenuItem className="text-gray-900 hover:bg-gray-100 focus:bg-gray-100">
                        <User className="w-4 h-4 mr-2" />
                        View Profile
                      </DropdownMenuItem>
                    </Link>
                  )}
                  <DropdownMenuSeparator className="bg-gray-200" />
                  <DropdownMenuItem onClick={logout} className="text-gray-900 hover:bg-gray-100 focus:bg-gray-100">
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ) : (
            null
          )}
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden p-2.5 text-foreground min-w-[44px] min-h-[44px] flex items-center justify-center"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle mobile menu"
        >
          {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-16 sm:top-20 left-0 right-0 bg-background border-b border-border/40 p-4 sm:p-6 flex flex-col gap-3 sm:gap-4 animate-in slide-in-from-top-5 shadow-xl z-40">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href} onClick={() => { scrollToTop(); setIsMobileMenuOpen(false); }}>
              <span
                className="text-base sm:text-lg font-medium text-foreground py-2.5 sm:py-3 cursor-pointer block min-h-[44px] flex items-center"
              >
                {link.label}
              </span>
            </Link>
          ))}
          <div className="h-px bg-border my-1 sm:my-2" />
          {isAuthenticated ? (
            <>
              {user?.is_admin && (
                <Link href="/admin">
                  <Button variant="outline" className="w-full justify-start min-h-[44px] px-4 py-2.5" onClick={() => setIsMobileMenuOpen(false)}>
                    <Shield className="w-4 h-4 mr-2 flex-shrink-0" />
                    Admin
                  </Button>
                </Link>
              )}
              {user?.profile_slug && (
                <Link href={`/member/${user.profile_slug}`}>
                  <Button variant="ghost" className="w-full justify-start min-h-[44px] px-4 py-2.5" onClick={() => setIsMobileMenuOpen(false)}>
                    <User className="w-4 h-4 mr-2 flex-shrink-0" />
                    View Profile
                  </Button>
                </Link>
              )}
              <Button variant="ghost" className="w-full justify-start min-h-[44px] px-4 py-2.5" onClick={() => { logout(); setIsMobileMenuOpen(false); }}>
                <LogOut className="w-4 h-4 mr-2 flex-shrink-0" />
                Logout
              </Button>
            </>
          ) : (
            null
          )}
        </div>
      )}
    </nav>
  );
}
