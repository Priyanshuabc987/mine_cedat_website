import { getImageUrl } from '@/lib/images';

const PLACEHOLDER_SVG = `data:image/svg+xml,${encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300"><rect fill="#f0f0f0" width="400" height="300"/><text x="200" y="155" text-anchor="middle" fill="#9ca3af" font-family="sans-serif" font-size="14">Image unavailable</text></svg>'
)}`;

interface ImageWithFallbackProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string | null | undefined;
}

/**
 * Renders an img that shows a placeholder when the source 404s or fails to load.
 * Use for API image URLs (e.g. /uploads/events/...) that may be missing on disk.
 */
export function ImageWithFallback({ src, alt = '', onError, ...props }: ImageWithFallbackProps) {
  const resolved = getImageUrl(src);

  if (!resolved) {
    return (
      <img
        src={PLACEHOLDER_SVG}
        alt={alt || 'Image unavailable'}
        {...props}
      />
    );
  }

  return (
    <img
      src={resolved}
      alt={alt}
      onError={(e) => {
        e.currentTarget.onerror = null;
        e.currentTarget.src = PLACEHOLDER_SVG;
        e.currentTarget.alt = alt || 'Image unavailable';
        onError?.(e);
      }}
      {...props}
    />
  );
}
